#!/bin/bash

# Kill any running Python processes
pkill -f 'python'

# Start the Flask application
python3 scripts/simple_pipeline_api.py
